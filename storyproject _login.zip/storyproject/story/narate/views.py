"""
Views for the narate app, including animated login and signup pages.
"""
from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.http import Http404

# Animated Login Page View
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'login.html', {'error': 'Invalid username or password'})
    
    return render(request, 'login.html')

# Animated Signup Page View
def signup_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        # Validate input
        if not username or not email or not password:
            return render(request, 'signup.html', {'error': 'All fields are required'})
        
        # Check if username exists
        if User.objects.filter(username=username).exists():
            return render(request, 'signup.html', {'error': 'Username already exists'})
        
        # Check if email exists
        if User.objects.filter(email=email).exists():
            return render(request, 'signup.html', {'error': 'Email already exists'})
        
        # Create new user
        user = User.objects.create_user(
            username=username,
            email=email,
            password=password
        )
        
        # Log the user in
        login(request, user)
        return redirect('home')
    
    return render(request, 'signup.html')

@login_required
def home(request):
    return render(request, 'home.html')

def binary_search_view(request):
    return render(request, 'BinarySearch.html')

def stack_view(request):
    return render(request, 'stack.html')

def array_view(request):
    return render(request, 'Array.html')

def string_view(request):
    return render(request, 'String.html')

def hash_table_view(request):
    return render(request, 'HashTable.html')

def dynamic_programming_view(request):
    return render(request, 'DynamicProgramming.html')

def math_view(request):
    return render(request, 'Math.html')

def sorting_view(request):
    return render(request, 'Sorting.html')

def greedy_view(request):
    return render(request, 'Greedy.html')

def dfs_view(request):
    return render(request, 'DepthFirstSearch.html')

def database_view(request):
    return render(request, 'Database.html')

def matrix_view(request):
    return render(request, 'Matrix.html')

def tree_view(request):
    return render(request, 'Tree.html')

def bfs_view(request):
    return render(request, 'BreadthFirstSearch.html')

def bit_manipulation_view(request):
    return render(request, 'BitManipulation.html')

def two_pointers_view(request):
    return render(request, 'TwoPointers.html')

def prefix_sum_view(request):
    return render(request, 'PrefixSum.html')

def heap_view(request):
    return render(request, 'Heap.html')

def simulation_view(request):
    return render(request, 'Simulation.html')

def binary_tree_view(request):
    return render(request, 'BinaryTree.html')

def graph_view(request):
    return render(request, 'Graph.html')

def counting_view(request):
    return render(request, 'Counting.html')

def sliding_window_view(request):
    return render(request, 'SlidingWindow.html')

def design_view(request):
    return render(request, 'Design.html')

def enumeration_view(request):
    return render(request, 'Enumeration.html')

def backtracking_view(request):
    return render(request, 'Backtracking.html')

def union_find_view(request):
    return render(request, 'UnionFind.html')

def linked_list_view(request):
    return render(request, 'LinkedList.html')

def ordered_set_view(request):
    return render(request, 'OrderedSet.html')

def number_theory_view(request):
    return render(request, 'NumberTheory.html')

def monotonic_stack_view(request):
    return render(request, 'MonotonicStack.html')

def segment_tree_view(request):
    return render(request, 'SegmentTree.html')

def trie_view(request):
    return render(request, 'Trie.html')

def combinatorics_view(request):
    return render(request, 'Combinatorics.html')

def bitmask_view(request):
    return render(request, 'Bitmask.html')

def recursion_view(request):
    return render(request, 'Recursion.html')

def queue_view(request):
    return render(request, 'Queue.html')

def divide_and_conquer_view(request):
    return render(request, 'DivideAndConquer.html')

def binary_indexed_tree_view(request):
    return render(request, 'BinaryIndexedTree.html')

def memoization_view(request):
    return render(request, 'Memoization.html')

def hash_function_view(request):
    return render(request, 'HashFunction.html')

def geometry_view(request):
    return render(request, 'Geometry.html')

def binary_search_tree_view(request):
    return render(request, 'BinarySearchTree.html')

def string_matching_view(request):
    return render(request, 'StringMatching.html')

def topological_sort_view(request):
    return render(request, 'TopologicalSort.html')

def shortest_path_view(request):
    return render(request, 'ShortestPath.html')

def rolling_hash_view(request):
    return render(request, 'RollingHash.html')

def monotonic_queue_view(request):
    return render(request, 'MonotonicQueue.html')

def doubly_linked_list_view(request):
    return render(request, 'DoublyLinkedList.html')

def counting_sort_view(request):
    return render(request, 'CountingSort.html')

def probability_statistics_view(request):
    return render(request, 'ProbabilityAndStatistics.html')

def quickselect_view(request):
    return render(request, 'Quickselect.html')

def suffix_array_view(request):
    return render(request, 'SuffixArray.html')

def bucket_sort_view(request):
    return render(request, 'BucketSort.html')

def minimum_spanning_tree_view(request):
    return render(request, 'MinimumSpanningTree.html')

def eulerian_circuit_view(request):
    return render(request, 'EulerianCircuit.html')

def radix_sort_view(request):
    return render(request, 'RadixSort.html')

def game_theory_view(request):
    return render(request, 'GameTheory.html')

def interactive_view(request):
    return render(request, 'Interactive.html')

def data_stream_view(request):
    return render(request, 'DataStream.html')

def brainteaser_view(request):
    return render(request, 'Brainteaser.html')

def randomized_view(request):
    return render(request, 'Randomized.html')

def merge_sort_view(request):
    return render(request, 'MergeSort.html')

def iterator_view(request):
    return render(request, 'Iterator.html')

def concurrency_view(request):
    return render(request, 'Concurrency.html')

def line_sweep_view(request):
    return render(request, 'LineSweep.html')

def shell_view(request):
    return render(request, 'Shell.html')

def reservoir_sampling_view(request):
    return render(request, 'ReservoirSampling.html')

def strongly_connected_component_view(request):
    return render(request, 'StronglyConnectedComponent.html')

def rejection_sampling_view(request):
    return render(request, 'RejectionSampling.html')

def biconnected_component_view(request):
    return render(request, 'BiconnectedComponent.html')

def template_view(request, template_name):
    # List of valid template names
    valid_templates = [
        'array', 'string', 'hash-table', 'dynamic-programming', 'math',
        'sorting', 'greedy', 'dfs', 'binary-search', 'database', 'matrix',
        'tree', 'bfs', 'bit-manipulation', 'two-pointers', 'prefix-sum',
        'heap', 'simulation', 'binary-tree', 'graph', 'counting',
        'sliding-window', 'design', 'enumeration', 'backtracking',
        'union-find', 'linked-list', 'ordered-set', 'number-theory',
        'monotonic-stack', 'segment-tree', 'trie', 'combinatorics',
        'bitmask', 'recursion', 'queue', 'divide-and-conquer',
        'binary-indexed-tree', 'memoization', 'hash-function', 'geometry',
        'binary-search-tree', 'string-matching', 'topological-sort',
        'shortest-path', 'rolling-hash', 'game-theory', 'interactive',
        'data-stream', 'monotonic-queue', 'brainteaser', 'doubly-linked-list',
        'randomized', 'merge-sort', 'counting-sort', 'iterator', 'concurrency',
        'probability-and-statistics', 'quickselect', 'suffix-array',
        'line-sweep', 'bucket-sort', 'minimum-spanning-tree', 'shell',
        'reservoir-sampling', 'strongly-connected-component', 'eulerian-circuit',
        'radix-sort', 'rejection-sampling', 'biconnected-component'
    ]
    
    # Convert template_name to match your file names
    template_name = template_name.replace('-', '_')
    
    if template_name in valid_templates:
        return render(request, f'{template_name}.html')
    else:
        raise Http404("Template not found")

def logout_view(request):
    logout(request)
    return redirect('login')



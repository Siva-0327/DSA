"""
URL configuration for story project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from narate import views as narate_views
from django.contrib.auth.decorators import login_required

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', narate_views.signup_view, name='signup'),
    path('login/', narate_views.login_view, name='login'),
    path('logout/', narate_views.logout_view, name='logout'),
    path('home/', login_required(narate_views.home), name='home'),
    path('templates/<str:template_name>/', narate_views.template_view, name='template_view'),
    path('array/', narate_views.array_view, name='array'),
    path('string/', narate_views.string_view, name='string'),
    path('hash-table/', narate_views.hash_table_view, name='hash_table'),
    path('dynamic-programming/', narate_views.dynamic_programming_view, name='dynamic_programming'),
    path('math/', narate_views.math_view, name='math'),
    path('sorting/', narate_views.sorting_view, name='sorting'),
    path('greedy/', narate_views.greedy_view, name='greedy'),
    path('dfs/', narate_views.dfs_view, name='dfs'),
    path('binary-search/', narate_views.binary_search_view, name='binary_search'),
    path('database/', narate_views.database_view, name='database'),
    path('matrix/', narate_views.matrix_view, name='matrix'),
    path('tree/', narate_views.tree_view, name='tree'),
    path('bfs/', narate_views.bfs_view, name='bfs'),
    path('bit-manipulation/', narate_views.bit_manipulation_view, name='bit_manipulation'),
    path('two-pointers/', narate_views.two_pointers_view, name='two_pointers'),
    path('prefix-sum/', narate_views.prefix_sum_view, name='prefix_sum'),
    path('heap/', narate_views.heap_view, name='heap'),
    path('simulation/', narate_views.simulation_view, name='simulation'),
    path('binary-tree/', narate_views.binary_tree_view, name='binary_tree'),
    path('graph/', narate_views.graph_view, name='graph'),
    path('counting/', narate_views.counting_view, name='counting'),
    path('sliding-window/', narate_views.sliding_window_view, name='sliding_window'),
    path('design/', narate_views.design_view, name='design'),
    path('enumeration/', narate_views.enumeration_view, name='enumeration'),
    path('backtracking/', narate_views.backtracking_view, name='backtracking'),
    path('union-find/', narate_views.union_find_view, name='union_find'),
    path('linked-list/', narate_views.linked_list_view, name='linked_list'),
    path('ordered-set/', narate_views.ordered_set_view, name='ordered_set'),
    path('number-theory/', narate_views.number_theory_view, name='number_theory'),
    path('monotonic-stack/', narate_views.monotonic_stack_view, name='monotonic_stack'),
    path('segment-tree/', narate_views.segment_tree_view, name='segment_tree'),
    path('trie/', narate_views.trie_view, name='trie'),
    path('combinatorics/', narate_views.combinatorics_view, name='combinatorics'),
    path('bitmask/', narate_views.bitmask_view, name='bitmask'),
    path('recursion/', narate_views.recursion_view, name='recursion'),
    path('queue/', narate_views.queue_view, name='queue'),
    path('divide-and-conquer/', narate_views.divide_and_conquer_view, name='divide_and_conquer'),
    path('binary-indexed-tree/', narate_views.binary_indexed_tree_view, name='binary_indexed_tree'),
    path('memoization/', narate_views.memoization_view, name='memoization'),
    path('hash-function/', narate_views.hash_function_view, name='hash_function'),
    path('geometry/', narate_views.geometry_view, name='geometry'),
    path('binary-search-tree/', narate_views.binary_search_tree_view, name='binary_search_tree'),
    path('string-matching/', narate_views.string_matching_view, name='string_matching'),
    path('topological-sort/', narate_views.topological_sort_view, name='topological_sort'),
    path('shortest-path/', narate_views.shortest_path_view, name='shortest_path'),
    path('rolling-hash/', narate_views.rolling_hash_view, name='rolling_hash'),
    path('game-theory/', narate_views.game_theory_view, name='game_theory'),
    path('interactive/', narate_views.interactive_view, name='interactive'),
    path('data-stream/', narate_views.data_stream_view, name='data_stream'),
    path('monotonic-queue/', narate_views.monotonic_queue_view, name='monotonic_queue'),
    path('brainteaser/', narate_views.brainteaser_view, name='brainteaser'),
    path('doubly-linked-list/', narate_views.doubly_linked_list_view, name='doubly_linked_list'),
    path('randomized/', narate_views.randomized_view, name='randomized'),
    path('merge-sort/', narate_views.merge_sort_view, name='merge_sort'),
    path('counting-sort/', narate_views.counting_sort_view, name='counting_sort'),
    path('iterator/', narate_views.iterator_view, name='iterator'),
    path('concurrency/', narate_views.concurrency_view, name='concurrency'),
    path('probability-and-statistics/', narate_views.probability_statistics_view, name='probability_and_statistics'),
    path('quickselect/', narate_views.quickselect_view, name='quickselect'),
    path('suffix-array/', narate_views.suffix_array_view, name='suffix_array'),
    path('line-sweep/', narate_views.line_sweep_view, name='line_sweep'),
    path('bucket-sort/', narate_views.bucket_sort_view, name='bucket_sort'),
    path('minimum-spanning-tree/', narate_views.minimum_spanning_tree_view, name='minimum_spanning_tree'),
    path('shell/', narate_views.shell_view, name='shell'),
    path('reservoir-sampling/', narate_views.reservoir_sampling_view, name='reservoir_sampling'),
    path('strongly-connected-component/', narate_views.strongly_connected_component_view, name='strongly_connected_component'),
    path('eulerian-circuit/', narate_views.eulerian_circuit_view, name='eulerian_circuit'),
    path('radix-sort/', narate_views.radix_sort_view, name='radix_sort'),
    path('rejection-sampling/', narate_views.rejection_sampling_view, name='rejection_sampling'),
    path('biconnected-component/', narate_views.biconnected_component_view, name='biconnected_component'),
]

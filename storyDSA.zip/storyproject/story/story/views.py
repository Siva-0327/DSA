from django.shortcuts import render

def template_view(request, template_name):
    return render(request, f'{template_name}.html') 